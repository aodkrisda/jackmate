#ifndef FRAME_PROCESSOR_H
#define FRAME_PROCESSOR_H

#endif // FRAME_PROCESSOR_H


char extractValue(Mat img);
