//#ifndef TABLESLIB_H
//#define TABLESLIB_H
#include "GameLib.hpp"

std::string getAdvice1Deck(hand player, hand dealer);

std::string getAdvice2Deck(hand player, hand dealer);

std::string getAdvice6Deck(hand player, hand dealer);

std::string getAdvice8Deck(hand player, hand dealer);


//#endif // TABLESLIB_H
